# FeatherX Android

Kotlin + Jetpack Compose starter frontend for a future Pojav-compatible Minecraft Java launcher.

## Build on GitHub Actions
1. Upload the contents of this project folder to the root of a GitHub repository.
2. Keep `.github/workflows/android.yml` in the repository.
3. Open the Actions tab and run **FeatherX Android APK Builder**.
4. Download the `FeatherX-Android-APK` artifact after a successful run.

## Build configuration
- JDK: 17
- Android compile SDK: 35
- Android Gradle Plugin: 8.9.1
- Gradle: 8.11.1
- Java and Kotlin JVM targets: 17

## Current scope
This is a launcher UI prototype. It does not yet include a playable Minecraft runtime, Microsoft sign-in, Minecraft version downloads, Fabric installation, working in-game HUD, shaders, or ReplayMod integration. Those require separate implementation and compatibility testing.

Use maintained runtime source code and comply with its license. Do not include Microsoft credentials or redistribute Mojang assets.
