# FeatherX Android — starter shell

A Kotlin + Jetpack Compose frontend prototype for a Pojav-compatible Minecraft Java launcher.

## Build
1. Open this folder in Android Studio.
2. Use JDK 17 for the Gradle build.
3. Let Gradle sync.
4. Build > Build APK(s).

The initial app is a **launcher UI prototype**, not a playable Minecraft client yet.

## Current status
- [x] Dark Compose UI and navigation
- [x] Starter version picker
- [x] Mods, servers, accounts and settings screens
- [x] Runtime adapter interface and domain models
- [ ] Integrate a maintained Pojav-compatible runtime
- [ ] Mojang version manifest and asset/library downloader
- [ ] Microsoft OAuth + Xbox/Minecraft entitlement flow
- [ ] Fabric installer and mod compatibility checks
- [ ] Secure profile storage and per-version game directories
- [ ] HUD implementation as Minecraft-side mod
- [ ] Shader compatibility testing on Android GPUs
- [ ] ReplayMod compatibility testing and FFmpeg/mobile export workflow

## Important engineering notes
The UI switches are placeholders and do not yet alter game performance. Real FPS gains come from compatible renderer/runtime choices and in-game mods/settings. ReplayMod and shader support depend on Minecraft version, mod compatibility, graphics driver, and Android hardware.

Use the current maintained runtime source and comply with its license. Do not redistribute Microsoft/Mojang assets or authentication tokens. Microsoft sign-in must use the supported OAuth flow and secure token storage.
