package com.featherx.client.core.servers

data class MinecraftServer(
    val name: String,
    val address: String,
    val port: Int = 25565,
    val versionHint: String? = null
)
