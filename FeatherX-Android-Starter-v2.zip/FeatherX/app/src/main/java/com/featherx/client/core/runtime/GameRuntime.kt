package com.featherx.client.core.runtime

/**
 * Boundary between the FeatherX UI and the Pojav-compatible game runtime.
 * Implement this against the selected runtime's documented APIs/source.
 * Do not attempt to launch an arbitrary external APK activity as an embedded runtime.
 */
interface GameRuntime {
    suspend fun installedVersions(): List<String>
    suspend fun launch(request: LaunchRequest): LaunchResult
}

data class LaunchRequest(
    val minecraftVersion: String,
    val loader: String? = null,
    val javaRuntimeId: String? = null,
    val maxMemoryMb: Int = 2048,
    val profileId: String
)

sealed interface LaunchResult {
    data object Started : LaunchResult
    data class Failed(val reason: String) : LaunchResult
}
