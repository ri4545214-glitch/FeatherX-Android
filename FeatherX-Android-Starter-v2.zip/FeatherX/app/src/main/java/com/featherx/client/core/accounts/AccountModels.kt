package com.featherx.client.core.accounts

data class MinecraftAccount(
    val id: String,
    val gamertag: String,
    val uuid: String,
    val accountType: AccountType
)

enum class AccountType { MICROSOFT, OFFLINE }

/** Store refresh tokens using Android Keystore-backed encryption; never plain preferences. */
interface AccountRepository {
    suspend fun accounts(): List<MinecraftAccount>
    suspend fun beginMicrosoftSignIn()
    suspend fun remove(accountId: String)
}
