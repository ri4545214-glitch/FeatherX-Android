package com.featherx.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF0B0D12)
private val SurfaceDark = Color(0xFF151923)
private val Accent = Color(0xFF8B5CF6)
private val Muted = Color(0xFF9AA4B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FeatherXApp() }
    }
}

@Composable
fun FeatherXApp() {
    var selected by remember { mutableStateOf("Home") }
    val tabs = listOf("Home", "Versions", "Mods", "Servers", "Accounts", "Settings")
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = SurfaceDark,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark) {
                    val icons = listOf(
                        Icons.Default.Home, Icons.Default.Gamepad,
                        Icons.Default.Extension, Icons.Default.Dns,
                        Icons.Default.AccountCircle, Icons.Default.Settings
                    )
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Icon(icons[index], contentDescription = tab) },
                            label = { Text(tab, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                indicatorColor = Accent.copy(alpha = .16f)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Home" -> HomeScreen(Modifier.padding(padding))
                "Versions" -> VersionsScreen(Modifier.padding(padding))
                "Mods" -> SimpleListScreen("Mod Manager", listOf("Fabric API", "Sodium", "Lithium", "Mod Menu", "ReplayMod"), Modifier.padding(padding))
                "Servers" -> SimpleListScreen("Server Browser", listOf("Add a server to get started"), Modifier.padding(padding))
                "Accounts" -> SimpleListScreen("Accounts", listOf("Microsoft account sign-in integration is not configured yet"), Modifier.padding(padding))
                else -> SettingsScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("FEATHERX", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Text("Your Minecraft.\nYour rules.", fontSize = 32.sp, fontWeight = FontWeight.Bold, lineHeight = 37.sp)
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("JAVA EDITION", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                Text("Ready for your next world?", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Choose a game version and configure your mods.", color = Muted)
                Button(onClick = { /* Runtime adapter will be connected in a later milestone. */ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("PLAY — runtime not connected")
                }
            }
        }
        Text("QUICK ACCESS", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTile("FPS Boost", "Performance", Modifier.weight(1f))
            QuickTile("Fabric", "Mod loader", Modifier.weight(1f))
        }
        QuickTile("Custom HUD", "Configure in-game overlays", Modifier.fillMaxWidth())
        Text("FeatherX 0.1.0 • Android launcher shell", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun QuickTile(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun VersionsScreen(modifier: Modifier = Modifier) {
    var selected by remember { mutableStateOf("1.21.4") }
    val versions = listOf("1.21.4", "1.21.1", "1.20.1", "1.19.4", "1.18.2", "1.16.5")
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Game Versions", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Starter list only. Live Mojang version metadata and downloads are not wired yet.", color = Muted)
        versions.forEach { version ->
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = Modifier.fillMaxWidth(),
                onClick = { selected = version }) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Minecraft $version", modifier = Modifier.weight(1f))
                    RadioButton(selected == version, onClick = { selected = version })
                }
            }
        }
        Text("Selected: $selected", color = Accent)
    }
}

@Composable
fun SimpleListScreen(title: String, entries: List<String>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(entries) { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = Modifier.fillMaxWidth()) {
                    Text(entry, Modifier.padding(16.dp))
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    var fps by remember { mutableStateOf(true) }
    var particles by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Performance", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        SettingSwitch("Performance preset (suggestions only)", fps) { fps = it }
        SettingSwitch("Reduce particles (in-game mod required)", particles) { particles = it }
        Text("These switches are UI placeholders. They do not change Minecraft until settings are passed to the runtime/mod configuration.", color = Muted)
    }
}

@Composable
fun SettingSwitch(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onCheckedChange = onChecked)
    }
}
