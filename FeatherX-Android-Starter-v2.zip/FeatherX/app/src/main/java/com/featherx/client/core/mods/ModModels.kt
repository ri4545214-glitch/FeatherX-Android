package com.featherx.client.core.mods

data class ModEntry(
    val id: String,
    val displayName: String,
    val fileName: String,
    val enabled: Boolean,
    val minecraftVersions: Set<String>,
    val loader: String = "fabric"
)

interface ModRepository {
    suspend fun list(profileId: String): List<ModEntry>
    suspend fun setEnabled(profileId: String, modId: String, enabled: Boolean)
    suspend fun install(profileId: String, sourceUri: String)
}
