package com.featherx.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF0B0E14)
private val SurfaceDark = Color(0xFF151B26)
private val Accent = Color(0xFF8B5CF6)
private val Muted = Color(0xFF9AA4B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FeatherXApp() }
    }
}

@Composable
private fun FeatherXApp() {
    var selected by remember { mutableStateOf("Home") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = SurfaceDark,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark) {
                    val tabs = listOf(
                        "Home" to Icons.Default.Home,
                        "Versions" to Icons.Default.ViewList,
                        "Mods" to Icons.Default.Extension,
                        "Servers" to Icons.Default.Dns,
                        "Settings" to Icons.Default.Settings
                    )
                    tabs.forEach { (name, icon) ->
                        NavigationBarItem(
                            selected = selected == name,
                            onClick = { selected = name },
                            icon = { Icon(icon, contentDescription = name) },
                            label = { Text(name, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                indicatorColor = Accent,
                                unselectedIconColor = Muted,
                                selectedTextColor = Color.White,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Home" -> HomeScreen(Modifier.padding(padding))
                "Versions" -> SimpleScreen("Minecraft Versions", "Version management will be connected to the game runtime in a future update.", Modifier.padding(padding))
                "Mods" -> SimpleScreen("Mods", "Fabric and mod installation are not connected yet.", Modifier.padding(padding))
                "Servers" -> SimpleScreen("Servers", "Your saved multiplayer servers will appear here.", Modifier.padding(padding))
                else -> SimpleScreen("Settings", "Launcher preferences and performance options.", Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun HomeScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("FEATHERX", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("ANDROID JAVA LAUNCHER", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Welcome back, Player", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Your Minecraft launcher dashboard", color = Muted)
                    Button(
                        onClick = { },
                        enabled = false,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(disabledContainerColor = Accent.copy(alpha = 0.45f))
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("GAME RUNTIME NOT CONNECTED")
                    }
                    Text(
                        "This build is the FeatherX interface prototype. It does not launch Minecraft yet.",
                        color = Muted,
                        fontSize = 12.sp
                    )
                }
            }
        }
        item { FeatureCard("Performance", "Launcher optimization controls are planned.", Icons.Default.Speed) }
        item { FeatureCard("Customization", "HUD, themes and client settings are planned.", Icons.Default.Tune) }
        item { FeatureCard("Mod support", "Fabric and mod management are planned.", Icons.Default.Extension) }
    }
}

@Composable
private fun FeatureCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(description, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SimpleScreen(title: String, description: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(description, color = Muted)
    }
}
