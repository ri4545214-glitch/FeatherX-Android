# FeatherX Android

FeatherX is an Android Jetpack Compose interface prototype for a future Minecraft Java launcher.

## Build with GitHub Actions (phone-friendly)

1. Create or open a GitHub repository.
2. Upload the **contents** of this folder, keeping the folder structure. Do not upload only the ZIP file.
3. Ensure `settings.gradle.kts` and `app/` are visible at the repository root.
4. Open the **Actions** tab.
5. Run **FeatherX Android APK** using **Run workflow**, or push a commit.
6. Open the completed workflow run and download the `FeatherX-debug-apk` artifact.

## Local build requirements

- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Gradle 8.11.1 or compatible Gradle 8.x

## Current implementation status

This package builds an Android application containing the FeatherX UI prototype: Home, Versions, Mods, Servers and Settings navigation.

**It is not yet a playable Minecraft launcher.** A Minecraft runtime, Microsoft authentication, game/version downloads, Fabric installation, mod loading, shaders, ReplayMod and in-game HUD are not implemented in this starter project.
